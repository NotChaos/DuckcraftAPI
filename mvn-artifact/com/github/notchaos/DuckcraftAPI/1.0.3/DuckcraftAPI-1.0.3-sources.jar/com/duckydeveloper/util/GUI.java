package com.duckydeveloper.util;

import com.duckydeveloper.DuckAPI;
import lombok.Getter;
import lombok.Setter;
import me.arcaniax.hdb.api.HeadDatabaseAPI;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class GUI {
    @Getter
    @Setter
    private String title;
    @Getter
    @Setter
    private int size;
    @Getter
    private final Inventory inventory;

    public GUI(@Nullable String title, @Nullable Integer size, @Nullable Inventory inventory) {
        this.title = title != null ? title : "GUI Title";
        this.size = size != null ? size : 27;
        if (inventory == null) {
            this.inventory = Bukkit.createInventory(null, this.size, Message.convertStringToLegacy(this.title));
        } else {
            this.inventory = inventory;
        }
    }

    public void setSlot(int slot, ItemStack item) {
        if (slot < 0 || slot >= inventory.getSize()) return;
        inventory.setItem(slot, item);
    }

    public ItemStack getSlot(int slot) {
        if (slot < 0 || slot >= inventory.getSize()) return null;
        return inventory.getItem(slot);
    }

    public static CompletableFuture<GUI> parseConfig(@NotNull String configPath) {
        boolean isDebug = DuckAPI.getDebug();

        if (isDebug) {
            DuckAPI.getPlugin().getLogger().info("[DuckAPI] Parsing GUI from config path: " + configPath);
        }

        Configuration config = DuckAPI.getPlugin().getConfig();

        int size;
        try {
            int cfgSize = config.getInt(configPath + ".Size", 0);
            if (cfgSize == 0) {
                int rows = config.getInt(configPath + ".Rows", 0);
                size = rows == 0 ? 27 : rows * 9;
                if (isDebug) {
                    DuckAPI.getPlugin().getLogger().info("[DuckAPI] Computed size from Rows: rows=" + rows + " -> size=" + size);
                }
            } else {
                size = cfgSize;
                if (isDebug) {
                    DuckAPI.getPlugin().getLogger().info("[DuckAPI] Using configured Size: " + cfgSize);
                }
            }
        } catch (Exception ignored) {
            size = 27;
            if (isDebug) {
                DuckAPI.getPlugin().getLogger().warning("[DuckAPI] Error reading size from config, falling back to default size=27");
            }
        }

        String title = config.getString(configPath + ".Title", "GUI Title");
        if (isDebug) {
            DuckAPI.getPlugin().getLogger().info("[DuckAPI] GUI title: " + title);
        }
        GUI gui = new GUI(title, size, null);
        if (isDebug) {
            DuckAPI.getPlugin().getLogger().info("[DuckAPI] Created GUI with size=" + gui.getSize() + " title=\"" + gui.getTitle() + "\"");
        }

        ConfigurationSection section = config.getConfigurationSection(configPath);
        if (section == null) {
            if (isDebug) {
                DuckAPI.getPlugin().getLogger().info("[DuckAPI] No configuration section found at: " + configPath + " - returning empty GUI");
            }
            return CompletableFuture.completedFuture(gui);
        }

        // Sequence future to ensure we process entries one-by-one and wait for head-owner/profile application
        CompletableFuture<Void> sequence = CompletableFuture.completedFuture(null);

        for (String key : section.getKeys(false)) {
            ConfigurationSection itemSection = section.getConfigurationSection(key);
            if (itemSection == null) {
                if (isDebug) {
                    DuckAPI.getPlugin().getLogger().info("[DuckAPI] Skipping key " + configPath + "." + key + " because it's not a section");
                }
                continue;
            }

            if (!itemSection.contains("Material") && !itemSection.contains("Slot") && !itemSection.contains("Name") && !itemSection.contains("Lore") && !itemSection.contains("HeadUUID") && !itemSection.contains("HeadDBId")) {
                if (isDebug) {
                    DuckAPI.getPlugin().getLogger().info("[DuckAPI] Skipping " + configPath + "." + key + " - no relevant fields found");
                }
                continue;
            }

            int slot = itemSection.getInt("Slot", 0);
            String matName = itemSection.getString("Material", "AIR");
            Material mat = Material.matchMaterial(matName);
            if (mat == null) {
                if (isDebug) {
                    DuckAPI.getPlugin().getLogger().info("[DuckAPI] Material '" + matName + "' not recognized, defaulting to AIR for " + configPath + "." + key);
                }
                mat = Material.AIR;
            }
            if (mat == Material.AIR) {
                if (isDebug) {
                    DuckAPI.getPlugin().getLogger().info("[DuckAPI] Skipping creation of AIR item for " + configPath + "." + key);
                }
                continue;
            }

            if (isDebug) {
                DuckAPI.getPlugin().getLogger().info("[DuckAPI] Creating item for " + configPath + "." + key + " with material " + mat);
            }
            ItemStack item = new ItemStack(mat);
            ItemMeta itemMeta = item.getItemMeta();

            if (itemMeta == null) {
                if (isDebug) {
                    DuckAPI.getPlugin().getLogger().warning("[DuckAPI] ItemMeta null for material " + mat + " at " + configPath + "." + key);
                }
                continue;
            }

            String headUuidString = itemSection.getString("HeadUUID");
            UUID headUuid = null;

            if (headUuidString != null && !headUuidString.isEmpty() && mat == Material.PLAYER_HEAD) {
                try {
                    headUuid = UUID.fromString(headUuidString);
                    ((SkullMeta) itemMeta).setOwningPlayer(Bukkit.getOfflinePlayer(headUuid));
                    if (isDebug) {
                        DuckAPI.getPlugin().getLogger().info("[DuckAPI] Set owning player for player head: " + headUuid);
                    }
                } catch (Exception e) {
                    if (isDebug) {
                        DuckAPI.getPlugin().getLogger().warning("[DuckAPI] Failed to parse/set HeadUUID '" + headUuidString + "' for " + configPath + "." + key + ": " + e.getMessage());
                    }
                }
            }

            itemMeta.getPersistentDataContainer().set(
                    new NamespacedKey(DuckAPI.getPlugin(), DuckAPI.getPersistentDataKey() + "isGuiItem"),
                    PersistentDataType.BOOLEAN, true
            );
            if (isDebug) {
                DuckAPI.getPlugin().getLogger().info("[DuckAPI] Marked item as GUI item in persistent data for " + configPath + "." + key);
            }

            itemMeta.setDisplayName(Message.convertStringToLegacy(itemSection.getString("Name", itemMeta.getDisplayName())));
            itemMeta.setLore(Message.convertStringListToLegacy(itemSection.getStringList("Lore")));
            item.setItemMeta(itemMeta);

            if (isDebug) {
                Bukkit.getLogger().info("[DuckAPI] Parsed GUI item at " + configPath + "." + key + " into slot " + slot);
                Bukkit.getLogger().info("[DuckAPI] Item Material: " + item.getType());
                Bukkit.getLogger().info("[DuckAPI] Item Name: " + itemMeta.getDisplayName());
                Bukkit.getLogger().info("[DuckAPI] Item Lore: " + itemMeta.getLore());
                if (headUuid != null) {
                    DuckAPI.getPlugin().getLogger().info("[DuckAPI] Player head name: " + Bukkit.getOfflinePlayer(headUuid));
                }
            }

            // Create a final copy of loop-local variables for use in lambdas
            final int fslot = slot;
            final ItemStack fitem = item;
            final String fheadDbId = itemSection.getString("HeadDBId");

            // Build a CompletableFuture step that will do fetch/apply on the correct threads
            CompletableFuture<Void> step;

            if (DuckAPI.getEnableHeadAPIIntegration() && mat == Material.PLAYER_HEAD && fheadDbId != null && !fheadDbId.isEmpty()) {
                if (isDebug) {
                    if (headUuid != null) DuckAPI.getPlugin().getLogger().info("[DuckAPI] Setting player head for UUID: " + headUuid);
                    DuckAPI.getPlugin().getLogger().info("[DuckAPI] Will fetch HeadDB ID: " + fheadDbId + " and wait for application before continuing");
                }

                // Async fetch, then apply on main thread and complete
                step = CompletableFuture.supplyAsync(() -> {
                    try {
                        if (isDebug) {
                            DuckAPI.getPlugin().getLogger().info("[DuckAPI] Obtaining HeadAPI and attempting to fetch HeadDB head for ID: " + fheadDbId);
                        }
                        HeadDatabaseAPI headAPI = DuckAPI.getHeadApiBlocking();
                        if (headAPI == null) {
                            if (isDebug) DuckAPI.getPlugin().getLogger().info("[DuckAPI] HeadAPI is not available; skipping HeadDB lookup for ID: " + fheadDbId);
                            return null;
                        }
                        return headAPI.getItemHead(fheadDbId);
                    } catch (Exception e) {
                        if (isDebug) DuckAPI.getPlugin().getLogger().warning("[DuckAPI] Exception while fetching HeadDB head for ID " + fheadDbId + ": " + e.getMessage());
                        return null;
                    }
                }).thenCompose(headItem -> {
                    // Create a future that completes when the main-thread application is done
                    CompletableFuture<Void> applied = new CompletableFuture<>();

                    Bukkit.getScheduler().runTask(DuckAPI.getPlugin(), () -> {
                        try {
                            if (headItem == null) {
                                if (isDebug) DuckAPI.getPlugin().getLogger().info("[DuckAPI] HeadDB did not return an item for ID: " + fheadDbId);
                                // still place the original item
                                if (fslot >= 0 && fslot < gui.getSize()) gui.setSlot(fslot, fitem);
                                applied.complete(null);
                                return;
                            }

                            if (!(headItem.getItemMeta() instanceof SkullMeta)) {
                                if (isDebug) DuckAPI.getPlugin().getLogger().info("[DuckAPI] HeadDB returned non-SkullMeta item for ID: " + fheadDbId);
                                if (fslot >= 0 && fslot < gui.getSize()) gui.setSlot(fslot, fitem);
                                applied.complete(null);
                                return;
                            }

                            SkullMeta headMeta = (SkullMeta) headItem.getItemMeta();
                            // Use retrying applicator to ensure the owning/profile becomes available
                            applyHeadWithRetries(fitem, headMeta, fslot, gui, 5, isDebug, applied);
                        } catch (Exception ex) {
                            if (isDebug) DuckAPI.getPlugin().getLogger().warning("[DuckAPI] Error applying HeadDB item for ID " + fheadDbId + ": " + ex.getMessage());
                            applied.complete(null);
                        }
                    });

                    return applied;
                });
            } else {
                // No HeadDB processing required; just place the item on main thread and wait until done
                step = CompletableFuture.supplyAsync(() -> {
                    CompletableFuture<Void> placed = new CompletableFuture<>();
                    Bukkit.getScheduler().runTask(DuckAPI.getPlugin(), () -> {
                        try {
                            if (fslot >= 0 && fslot < gui.getSize()) gui.setSlot(fslot, fitem);
                        } catch (Exception ex) {
                            if (isDebug) DuckAPI.getPlugin().getLogger().warning("[DuckAPI] Error placing GUI item at slot " + fslot + ": " + ex.getMessage());
                        }
                        placed.complete(null);
                    });
                    try { return placed.get(); } catch (Exception e) { return null; }
                }).thenApply(v -> null);
            }

            // Chain the step so we wait for each entry to finish before processing the next
            sequence = sequence.thenCompose(ignored -> step);
        }

        // Return the GUI once the entire sequence is complete
        return sequence.thenApply(ignored -> gui);
    }

    // Try to apply the skull meta to the item, and wait and retry a few times if the profile/owner isn't present yet.
    private static void applyHeadWithRetries(ItemStack item, SkullMeta headMeta, int slot, GUI gui, int attemptsLeft, boolean isDebug, CompletableFuture<Void> done) {
        // run the attempt on the main thread
        Bukkit.getScheduler().runTask(DuckAPI.getPlugin(), () -> {
            try {
                ItemMeta currentMeta = item.getItemMeta();
                SkullMeta skullMeta = null;
                if (currentMeta instanceof SkullMeta) skullMeta = (SkullMeta) currentMeta;

                if (skullMeta != null && headMeta.getPlayerProfile() != null) {
                    skullMeta.setPlayerProfile(headMeta.getPlayerProfile());
                    item.setItemMeta(skullMeta);
                } else if (skullMeta != null && headMeta.getOwningPlayer() != null) {
                    skullMeta.setOwningPlayer(headMeta.getOwningPlayer());
                    item.setItemMeta(skullMeta);
                } else {
                    // fallback: copy the headMeta onto the item
                    ItemMeta preserved = currentMeta;
                    item.setItemMeta(headMeta);
                    ItemMeta newMeta = item.getItemMeta();
                    if (newMeta != null) {
                        try { newMeta.setDisplayName(preserved.getDisplayName()); } catch (Exception ignored) {}
                        try { newMeta.setLore(preserved.getLore()); } catch (Exception ignored) {}
                        try {
                            newMeta.getPersistentDataContainer().set(
                                    new NamespacedKey(DuckAPI.getPlugin(), DuckAPI.getPersistentDataKey() + "isGuiItem"),
                                    PersistentDataType.BOOLEAN, true
                            );
                        } catch (Exception ignored) {}
                        item.setItemMeta(newMeta);
                    }
                }

                // Verify if owner/profile is present now
                ItemMeta verifyMeta = item.getItemMeta();
                boolean applied = false;
                if (verifyMeta instanceof SkullMeta) {
                    SkullMeta v = (SkullMeta) verifyMeta;
                    if (v.getPlayerProfile() != null) applied = true;
                    else if (v.getOwningPlayer() != null) {
                        try { if (v.getOwningPlayer().getUniqueId() != null) applied = true; } catch (Exception ignored) {}
                    }
                }

                if (applied || attemptsLeft <= 0) {
                    if (slot >= 0 && slot < gui.getSize()) gui.setSlot(slot, item);
                    if (isDebug) DuckAPI.getPlugin().getLogger().info("[DuckAPI] Applied HeadDB profile (or final fallback) and placed GUI slot " + slot + " (applied=" + applied + ")");
                    done.complete(null);
                } else {
                    // schedule another attempt in a few ticks
                    if (isDebug) DuckAPI.getPlugin().getLogger().info("[DuckAPI] Head not applied yet; retrying for slot " + slot + " attemptsLeft=" + attemptsLeft);
                    Bukkit.getScheduler().runTaskLater(DuckAPI.getPlugin(), () -> applyHeadWithRetries(item, headMeta, slot, gui, attemptsLeft - 1, isDebug, done), 2L);
                }
            } catch (Exception e) {
                if (isDebug) DuckAPI.getPlugin().getLogger().warning("[DuckAPI] applyHeadWithRetries error: " + e.getMessage());
                try { if (slot >= 0 && slot < gui.getSize()) gui.setSlot(slot, item); } catch (Exception ignored) {}
                done.complete(null);
            }
        });
    }
}
